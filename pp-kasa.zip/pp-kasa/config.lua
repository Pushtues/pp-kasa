Config = {}

Config.Kasalar = {  -- Kasa propu 
    "prop_till_01"
}
Config.CopsRequired = 1  -- polis sayısı 


-- Pushtues#9517