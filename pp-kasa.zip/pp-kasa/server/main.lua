local ESX = nil

TriggerEvent("esx:getSharedObject", function(obj) 
    ESX = obj 
end)

RegisterServerEvent("pp:reward")
AddEventHandler("pp:reward", function()
    local player = ESX.GetPlayerFromId(source)

    local luck = math.random(0, 69)

    if luck >= 0 and luck <= 29 then
        player.addInventoryItem('cash', math.random(300,500))
    else
        player.addInventoryItem("cash", math.random(100,300))
    end
end)

ESX.RegisterServerCallback('pp:anycops', function(source, cb)
    local anycops = 0
    local playerList = GetPlayers()
    for i = 1, #playerList, 1 do
        local _source = playerList[i]
        local xPlayer = ESX.GetPlayerFromId(_source)
        local playerjob = xPlayer.job.name
        if playerjob == 'police' then
            anycops = anycops + 1
        end
    end
    cb(anycops)
end)

RegisterServerEvent('pp:removemaymuncuk')
AddEventHandler('pp:removemaymuncuk', function()

	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)

	xPlayer.removeInventoryItem('lockpick', 1)
end)

ESX.RegisterUsableItem('lockpick', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)
	TriggerClientEvent('pp:kasa', source)
	Citizen.Wait(1000)
end)

-- Pushtues#9517