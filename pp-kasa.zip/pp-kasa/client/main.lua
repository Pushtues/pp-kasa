ESX  = nil

local cachedKasa = {}
local clientcooldown = false

Citizen.CreateThread(function ()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) 
            ESX = obj 
        end)

        Citizen.Wait(5)
    end
end)

RegisterNetEvent("pp:kasa")
AddEventHandler("pp:kasa", function()
        local sleepThread = 1000
        local entity, entityDst = ESX.Game.GetClosestObject(Config.Kasalar)
        if DoesEntityExist(entity) and entityDst <= 1.5 then
            sleepThread = 5
            local kasaCoords = GetEntityCoords(entity)
                if not clientcooldown then
                ESX.TriggerServerCallback('pp:anycops', function(anycops)
                if anycops >= Config.CopsRequired then
                if not cachedKasa[entity] then
                    cachedKasa[entity] = true
                    OpenppKasa()
                else
                    exports['mythic_notify']:DoHudText('error', 'Kasayı zaten soydun!')
                end
            else 
                exports['mythic_notify']:DoHudText('error', 'Yeterli Polis Yok!')
            end
            end)
         -- end, "lockpick")
        end
        if clientcooldown then
            exports['mythic_notify']:SendAlert('error', 'Bu kasayı zaten soydun!')
        end
            end
--        end
        Citizen.Wait(sleepThread)
end)


function OpenppKasa()
    TriggerServerEvent('pp:removemaymuncuk')
    TriggerEvent('police:kasiyers') -- Bildirim pp-outlawalertnew
    exports['progressBars']:startUI(10100, "Paralar Alınıyor...")
    TaskStartScenarioInPlace(PlayerPedId(), "PROP_HUMAN_ATM", 0, true)
    Citizen.Wait(10000)

    TriggerServerEvent("pp:reward")

    ClearPedTasks(PlayerPedId())
    Citizen.Wait(1000)
    clientcooldown = true
    Citizen.Wait(120000)
    clientcooldown = false
end

-- Pushtues#9517

